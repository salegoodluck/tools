# eBay Worker

This is a simple program which will allow its users to scrap books data from eBay listings. This data may be useful for merchants who sell books on various online stores after purchasing used or new books from eBay on competitive prices. Data is exported in CSV file format with single book detail per line.
