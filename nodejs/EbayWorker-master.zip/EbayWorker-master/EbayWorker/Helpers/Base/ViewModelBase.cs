﻿namespace EbayWorker.Helpers.Base
{
    public abstract class ViewModelBase: NotificationBase
    {
        
    }
}
